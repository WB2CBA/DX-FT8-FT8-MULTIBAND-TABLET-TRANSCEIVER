/*
 * log_file.h
 *
 *  Created on: Oct 29, 2019
 *      Author: user
 */

#ifndef LOG_FILE_H_
#define LOG_FILE_H_

void Write_Log_Data(const char *ch);
void Write_RxTxLog_Data(const char *str);
void Close_Log_File(void);
void Open_Log_File(void);
void Init_Log_File(void);

#endif /* LOG_FILE_H_ */
