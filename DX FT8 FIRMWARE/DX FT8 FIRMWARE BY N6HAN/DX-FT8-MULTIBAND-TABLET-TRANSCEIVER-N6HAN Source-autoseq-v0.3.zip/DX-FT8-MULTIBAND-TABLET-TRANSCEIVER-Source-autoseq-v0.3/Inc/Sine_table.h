/*
 * Sine_table.h
 *
 *  Created on: Oct 19, 2024
 *      Author: Paul
 */

#ifndef SINE_TABLE_H_
#define SINE_TABLE_H_

extern const int Sine_table[];

#endif /* SINE_TABLE_H_ */
